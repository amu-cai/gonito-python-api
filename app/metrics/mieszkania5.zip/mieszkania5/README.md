Mieszkania5 challenge
=====================

Guess the price of a flat/house.

The metric is absolute mean error.
